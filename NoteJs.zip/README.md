Note.js

⇝ A simple educational language made by Alsek

INSTALLATION 

To install Note.js, first download the zip file, then go to your terminal and type the command: node note.js 

That's it!