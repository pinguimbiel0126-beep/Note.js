const fs = require("fs");

const arquivo = fs.readFileSync("aula.note", "utf8");

const linhas = arquivo.split("\n");

for (let linha of linhas) {linha = linha.trim();
  
  if (linha.startsWith("text ")) {
    const texto = linha.slice(5);
    
    console.log(texto);
  }
}